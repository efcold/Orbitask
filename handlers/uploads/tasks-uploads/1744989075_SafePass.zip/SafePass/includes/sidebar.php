<?php
$plansRef = "users/{$uid}/plans/";
$myPlansRaw = $database->getReference($plansRef)->getValue() ?? [];
// Helper to sanitize emails into Firebase keys
$myPlans = [];
foreach ($myPlansRaw as $planId => $plan) {
    if (!empty($plan['title']) && !empty($plan['date'])) {
        // You might want to add the plan ID to each plan object:
        $plan['plan_id'] = $planId;
        $myPlans[] = $plan;
    }
}

?>
<div class="sidebar">
  <h2>Navigation</h2>
  <a href="dashboard.php">My Plans</a>
  <a href="calendar.php">Calendar</a>
  <div class="plan-list-section">
      <!-- Your Plans Section -->
      <h3 class="plans-section-title">Your Plans</h3>
      <?php if (!empty($myPlans)) : ?>
        <?php foreach ($myPlans as $plan): 
          // Build URL for owner's plan
          $viewUrl = "viewplan.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($uid);
        ?>
          <div class="plan-item">
            <div class="plan-header">
              <div class="plan-title"><?php echo htmlspecialchars($plan['title']); ?></div>
              <a class="btn-go" href="<?php echo $viewUrl; ?>">Go to</a>
            </div>
            <div class="plan-status">
              <?php echo isset($plan['status']) ? htmlspecialchars($plan['status']) : 'Unknown'; ?>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
          <p>No plans found.</p>
      <?php endif; ?>

      <!-- Invited Plans Section -->
      <h3 class="invplans-section-title">Invited Plans</h3>
      <?php if (!empty($invitedPlans)) : ?>
        <?php foreach ($invitedPlans as $plan): 
          // Build URL for invited plan
          $viewUrl = "viewinvplans.php?plan_id=" . urlencode($plan['plan_id']) . "&owner_uid=" . urlencode($plan['owner']);
        ?>
          <div class="plan-item">
            <div class="plan-header">
              <div class="plan-title"><?php echo htmlspecialchars($plan['title']); ?></div>
              <a class="btn-go" href="<?php echo $viewUrl; ?>">Go to</a>
            </div>
            <div class="plan-status">
              <?php echo isset($plan['status']) ? htmlspecialchars($plan['status']) : 'Unknown'; ?>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
          <p>No invited plans found.</p>
      <?php endif; ?>
    </div>
    <a href="../auth/logout.php">Logout</a>
</div>