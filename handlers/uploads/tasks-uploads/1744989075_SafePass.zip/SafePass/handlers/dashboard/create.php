<?php
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    return;
}
if (isset($_POST['create_plan'])) {
    $tasksArray = [];
    if (!empty($_POST['tasks_json'])) {
    $taskItems = json_decode($_POST['tasks_json'], true);
    if (is_array($taskItems)) {
        foreach ($taskItems as $task) {
            $tasksArray[uniqid()] = [
                "name"       => htmlspecialchars($task['name']),
                "due_date"   => htmlspecialchars($task['due_date']),
                "due_time"   => htmlspecialchars($task['due_time']),
                "completed"  => false
            ];
        }        
    }
}

    $startDate = $_POST['start_date']; 
    $endDate   = $_POST['end_date']; 

    $status = "In Progress";

    $newPlanRef = $database->getReference($plansRef)->push();
    $newPlanRef->set([
        "creator"    => $uid,
        "title"      => $_POST['title'],
        "start_date" => $startDate,
        "end_date"   => $endDate,
        "status"     => $status,
        "tasks"      => $tasksArray,
        "invited"    => []
    ]);
    header("Location: dashboard.php");

    exit();
}

if (isset($_POST['accept_invite'])) {
    $inviteKey = $_POST['invite_key']  ?? null;
    $planId    = $_POST['plan_id']     ?? null;
    $ownerUid  = $_POST['owner_uid']   ?? null;

    if ($inviteKey && $planId && $ownerUid) {
        $invitationRef = $database->getReference("invitations/{$myEmailKey}/{$inviteKey}");
        // mark accepted
        $invitationRef->update(['accepted' => true]);
        // <-- add this line to remove the ignored flag:
        $database
          ->getReference("invitations/{$myEmailKey}/{$inviteKey}/ignored")
          ->remove();

        // add to the plan’s invited list
        $database
          ->getReference("users/{$ownerUid}/plans/{$planId}/invited/{$myEmailKey}")
          ->set('accepted');
    }

    header("Location: invites.php?plan_id=".urlencode($planId)."&owner_uid=".urlencode($ownerUid));
    exit();
}

if (isset($_POST['ignore_invite'])) {
    $inviteKey = $_POST['invite_key'] ?? null;
    if ($inviteKey) {
        $invitationRef = $database->getReference("invitations/{$myEmailKey}/{$inviteKey}");
        $invitationRef->update(['ignored' => true]);
    }
    $viewUrl = "archive.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($ownerUid);
    header("Location: " . $viewUrl);
    exit();
}

?>