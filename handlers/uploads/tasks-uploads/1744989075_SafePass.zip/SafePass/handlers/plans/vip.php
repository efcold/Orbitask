<?php
if (isset($_POST['toggle_task'])) {
    $planId    = $_POST['plan_id'];
    $taskId    = $_POST['task_id'];
    $planPath  = "users/{$ownerUid}/plans/{$planId}/tasks/{$taskId}";
    $taskRef   = $database->getReference($planPath);
    $taskData  = $taskRef->getValue();

    if ($taskData !== null) {
        $currentStatus = $taskData['completed'] ?? false;
        $taskRef->update(['completed' => !$currentStatus]);
    }
    $viewUrl = "viewinvplans.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($ownerUid);
    header("Location: " . $viewUrl);
    exit();
}
if (isset($_POST['leave_plan'])) {
    $planId = $_POST['plan_id'];
    $ownerUid = $_POST['owner_uid'];
    $inviteKey = $_POST['invite_key'];
    $currentEmailKey = sanitizeEmail($currentUserEmail);

    if (!empty($inviteKey)) {
        $database->getReference("invitations/{$currentEmailKey}/{$inviteKey}")->remove();
    }

    $database->getReference("users/{$ownerUid}/plans/{$planId}/invited/{$currentEmailKey}")->remove();

    header("Location: dashboard.php");
    exit();
}
?>