<?php
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    return;
}

if (isset($_POST['update_status'])) {
    $planId = $_POST['plan_id'];
    $newStatus = $_POST['status']; 
    $planRef = $database->getReference("users/{$uid}/plans/{$planId}");
    $planRef->update([
        "status" => $newStatus
    ]);
    $viewUrl = "viewplan.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($uid);
    header("Location: " . $viewUrl);
    exit();
}

if (isset($_POST['toggle_task'])) {
    $planId    = $_POST['plan_id'];
    $taskId    = $_POST['task_id'];
    $ownerUid  = $_POST['owner_uid'] ?? $uid;
    $planPath  = "users/{$ownerUid}/plans/{$planId}/tasks/{$taskId}";
    $taskRef   = $database->getReference($planPath);
    $taskData  = $taskRef->getValue();

    if ($taskData !== null) {
        $currentStatus = $taskData['completed'] ?? false;
        $taskRef->update(['completed' => !$currentStatus]);
    }
    $viewUrl = "viewplan.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($uid);
    header("Location: " . $viewUrl);
    exit();
}

if (isset($_POST['add_task'])) {
    $planId   = $_POST['plan_id'];
    $taskName = trim($_POST['task_name'] ?? '');
    $dueDate  = $_POST['due_date'] ?? '';
    $dueTime  = $_POST['due_time'] ?? '';

    if ($taskName !== '') {
        $taskRef = $database
            ->getReference("users/{$uid}/plans/{$planId}/tasks")
            ->push();

        $taskRef->set([
            "name"       => htmlspecialchars($taskName),
            "due_date"   => htmlspecialchars($dueDate),
            "due_time"   => htmlspecialchars($dueTime),
            "completed"  => false
        ]);
    }

    $viewUrl = "viewplan.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($uid);
    header("Location: " . $viewUrl);
    exit();
}



use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\OAuth;
use League\OAuth2\Client\Provider\Google;

if (isset($_POST['invite_user'])) {
    $planId = $_POST['plan_id'];
    $inviteEmail = $_POST['invite_email'];
    $inviteRole = $_POST['invite_role']; 
    $inviteEmailKey = sanitizeEmail($inviteEmail);
    $invitedRef = $database->getReference("users/{$uid}/plans/{$planId}/invited/{$inviteEmailKey}");
    $alreadyInvited = $invitedRef->getValue();

    if (!$alreadyInvited) {
        // Record the invitation in your Firebase database
        $invitedRef->set($inviteRole);
        $invitationData = [
            "plan_id" => $planId,
            "owner"   => $uid,
            "role"    => $inviteRole,
            "email"   => $inviteEmail  // Save the actual email for reference
        ];
        $database->getReference("invitations/{$inviteEmailKey}")
            ->push()
            ->set($invitationData);


        $mail = new PHPMailer(true);
        
        try {
            // Tell PHPMailer to use SMTP
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->Port       = 587;
            $mail->SMTPSecure = 'tls';
            $mail->SMTPAuth   = true;
            
            // Set the AuthType to XOAUTH2
            $mail->AuthType   = 'XOAUTH2';
        
            // Create a new OAuth2 provider instance
            $provider = new Google(
                [
                    'clientId'     => '530491108453-7kpslds8aj5nencleap23m3mic6c2gt0.apps.googleusercontent.com',       // Replace with your Client ID
                    'clientSecret' => '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',   // Replace with your Client Secret
                ]
            );
        
            // Pass the OAuth2 instance to PHPMailer
            $mail->setOAuth(
                new OAuth(
                    [
                        'provider'     => $provider,
                        'clientId'     => '530491108453-7kpslds8aj5nencleap23m3mic6c2gt0.apps.googleusercontent.com',        // Your Client ID again
                        'clientSecret' => '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',    // Your Client Secret again
                        'refreshToken' => '1//044R_UxD6FygCCgYIARAAGAQSNwF-L9Ir6nzrlEevkPrykwUFQv3SKk14TJBvAFoA5LXC2BG8Mez9jvV7v5XEd4isWR6IJtuAm9A',      // The Refresh Token you obtained
                        'userName'     => 'rosswellacabo2004@gmail.com',    // Your Gmail address
                    ]
                )
            );
        
            // Email Headers and Recipients
            $mail->setFrom('rosswellacabo2004@gmail.com', 'DigitalPlanner');
            $mail->addAddress($inviteEmail);
            $mail->addReplyTo('rosswellacabo2004@gmail.com', 'DigitalPlanner');
        
            // Email Content
            $mail->isHTML(true);
            $mail->Subject = 'You have been invited to collaborate on a plan!';
            $mail->Body    = "
                <h2>Hello!</h2>
                <p>You have been invited to collaborate on a plan in <strong>DigitalPlanner</strong>.</p>
                <p><strong>Role:</strong> $inviteRole</p>
                <p>Click below to view the plan:</p>
                <a href='https://yourwebsite.com/viewplan.php?plan_id={$planId}&owner_uid={$uid}'>View Plan</a>
                <p>Thank you!</p>
            ";
        
            $mail->send();
            echo 'Message has been sent successfully';
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }

    $viewUrl = "viewplan.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($uid);
    header("Location: " . $viewUrl);
    exit();
}
}

if (isset($_POST['add_announcement'])) {
    $planId = $_POST['plan_id'];
    $announcementText = trim($_POST['announcement_text']);
    if (!empty($announcementText)) {
        $announcementRef = $database->getReference("users/$uid/plans/$planId/announcements")->push();
        $announcementRef->set([
            'text' => htmlspecialchars($announcementText),
            'timestamp' => time(),
        ]);
    }
    $viewUrl = "viewplan.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($uid);
    header("Location: " . $viewUrl);
    exit();
}

if (isset($_POST['add_note'])) {
    $planId   = $_POST['plan_id'];
    $noteText = trim($_POST['note_text']);
    $targetUid = isset($_POST['owner_uid']) && !empty($_POST['owner_uid']) ? $_POST['owner_uid'] : $uid;

    if (!empty($noteText)) {
        $noteRef = $database->getReference("users/{$targetUid}/plans/{$planId}/notes")->push();
        $noteRef->set([
            'author'    => $currentUserEmail,
            'text'      => htmlspecialchars($noteText),
            'timestamp' => time(),
        ]);
    }
    $viewUrl = "viewplan.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($uid);
    header("Location: " . $viewUrl);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_plan'])) {
    $deletePlanId = $_POST['plan_id'];
    $planPath = "users/{$uid}/plans/{$deletePlanId}";

    $database->getReference($planPath)->remove();    
    $invitedPath = "users/{$uid}/plans/{$deletePlanId}/invited";
    $invitedUsers = $database->getReference($invitedPath)->getValue();

    if ($invitedUsers) {
        foreach ($invitedUsers as $emailKey => $invitedData) {
            $database->getReference("invitations/{$emailKey}")
                     ->getChildKeys()
                     ->then(function($inviteKeys) use ($deletePlanId, $database, $emailKey) {
                         foreach ($inviteKeys as $inviteKey) {
                             $database->getReference("invitations/{$emailKey}/{$inviteKey}")->remove();
                         }
                     });
        }
    }

    header("Location: dashboard.php");
    exit();
}
