<?php
ob_start();
session_start();

if (!isset($_SESSION["uid"])) {
    header("Location: ../auth/login.php");
    exit();
}

$currentUserEmail = $_SESSION['email'] ?? '';
$uid = $_SESSION['uid'];

require __DIR__ . '/../vendor/autoload.php';
use Kreait\Firebase\Factory;

$factory = (new Factory)
    ->withServiceAccount(__DIR__ . '/../ms-digitalplanner-firebase-adminsdk-fbsvc-dc1c731d47.json')
    ->withDatabaseUri('https://ms-digitalplanner-default-rtdb.firebaseio.com/');
$database = $factory->createDatabase();

function sanitizeEmail(string $email): string {
    return str_replace(['.', '#', '$', '[', ']'], '_', $email);
}

$myEmailKey = sanitizeEmail($currentUserEmail);

$myPlansRef = "users/{$uid}/plans";
$myPlans = $database->getReference($myPlansRef)->getValue() ?? [];

$invitationsRef = "invitations/{$myEmailKey}";
$invitations = $database->getReference($invitationsRef)->getValue() ?? [];

$allEvents = [];

// My Plans
foreach ($myPlans as $planId => $plan) {
    // Main plan event
    $allEvents[] = [
        'title'    => $plan['title'] ?? 'Untitled',
        'start'    => $plan['start_date'] ?? '',
        'end'      => $plan['end_date'] ?? '',
        'plan_id'  => $planId,
        'owner'    => $uid,
        'isOwner'  => true,
    ];

    // Tasks within the plan
    $tasks = $plan['tasks'] ?? [];
    foreach ($tasks as $taskId => $task) {
        if (!empty($task['due_date'])) {
            $allEvents[] = [
                'title'    => '[Task] ' . ($task['name'] ?? 'Untitled Task'),
                'start'    => $task['due_date'],
                'allDay'   => true,
                'plan_id'  => $planId,
                'owner'    => $uid,
                'isOwner'  => true,
                'backgroundColor' => '#f0ad4e', // Different color for tasks
                'textColor' => '#fff'
            ];
        }
    }
}

// Invited Plans
foreach ($invitations as $inv) {
    if (!empty($inv['plan_id']) && !empty($inv['owner'])) {
        $planDetail = $database->getReference("users/{$inv['owner']}/plans/{$inv['plan_id']}")->getValue();
        if ($planDetail) {
            // Main plan event
            $allEvents[] = [
                'title'    => $planDetail['title'] ?? 'Untitled',
                'start'    => $planDetail['start_date'] ?? '',
                'end'      => $planDetail['end_date'] ?? '',
                'plan_id'  => $inv['plan_id'],
                'owner'    => $inv['owner'],
                'isOwner'  => false,
            ];

            // Tasks within the invited plan
            $tasks = $planDetail['tasks'] ?? [];
            foreach ($tasks as $taskId => $task) {
                if (!empty($task['due_date'])) {
                    $allEvents[] = [
                        'title'    => '[Task] ' . ($task['name'] ?? 'Untitled Task'),
                        'start'    => $task['due_date'],
                        'allDay'   => true,
                        'plan_id'  => $inv['plan_id'],
                        'owner'    => $inv['owner'],
                        'isOwner'  => false,
                        'backgroundColor' => '#5bc0de', // Different color for invited tasks
                        'textColor' => '#fff'
                    ];
                }
            }
        }
    }
}

header('Content-Type: application/json');
echo json_encode($allEvents);
?>
