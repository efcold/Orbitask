
  function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const body = document.body;

    if (window.innerWidth <= 768) {
      sidebar.classList.toggle('active');
    } else {
      sidebar.classList.toggle('collapsed');
      body.classList.toggle('sidebar-collapsed');
    }
  }

