
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login with Google</title>

    <script src="https://www.gstatic.com/firebasejs/10.11.0/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/10.11.0/firebase-auth-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/10.11.0/firebase-database-compat.js"></script>

    <script src="../conn/firebase-config.js"></script>
    <script src="../conn/auth.js"></script>
</head>
<body>
    <h2>Login with Google</h2>
    <button id="googleLoginBtn">Sign in with Google</button>
</body>
</html>
