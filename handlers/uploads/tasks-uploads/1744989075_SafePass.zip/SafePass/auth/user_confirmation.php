<?php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle form submission: get JSON data from request body
    $data = json_decode(file_get_contents("php://input"), true);
    if ($data && isset($data["uid"])) {
        $firebaseUrl = "https://ms-digitalplanner-default-rtdb.firebaseio.com/users/{$data['uid']}.json";
        $userData = json_encode([
          "uid" => $data["uid"],
          "email" => $data["email"],
          "name" => $data["displayName"],
          "phone" => $data["phone"],
          "address" => $data["address"],
          "photoURL" => $data["photoURL"] ?? '' // 👈 store image
      ]);
      
        // Save data to Firebase using a PUT request
        $options = [
            "http" => [
                "header"  => "Content-Type: application/json",
                "method"  => "PUT",
                "content" => $userData,
            ],
        ];
        $context  = stream_context_create($options);
        file_get_contents($firebaseUrl, false, $context);
        
        // Set PHP session data and return success response
        $_SESSION["uid"] = $data["uid"];
        $_SESSION["email"] = $data["email"];
        echo json_encode(["status" => "success"]);
        exit();
    } else {
        echo json_encode(["status" => "error", "message" => "Invalid data"]);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Confirm Your Details</title>
</head>
<body>
  <h2>Confirm Your Details</h2>
  <form id="confirmForm">
  <div id="profilePic" class="avatar" style="width: 120px; height: 120px; border-radius: 50%; display: flex; justify-content: center; align-items: center; background-color: #4CAF50; color: white; font-size: 48px; font-weight: bold; margin-bottom: 20px;">
    <!-- Default Avatar will be the first letter of the name -->
  </div>

    <input type="hidden" id="uid" name="uid" value="">
    <label for="name">Name:</label>
    <input type="text" id="name" name="displayName" required>
    <br>
    <label for="email">Email:</label>
    <input type="email" id="email" name="email" readonly>
    <br>
    <label for="phone">Phone:</label>
    <input type="text" id="phone" name="phone">
    <br>
    <label for="address">Address:</label>
    <input type="text" id="address" name="address">
    <br>
    <button type="submit">Save & Continue</button>
  </form>
  <script>
document.addEventListener("DOMContentLoaded", function () {
  const userData = JSON.parse(sessionStorage.getItem("userData"));


  if (userData) {
    document.getElementById("uid").value = userData.uid;
    document.getElementById("name").value = userData.displayName;
    document.getElementById("email").value = userData.email;

  
    const profilePicElement = document.getElementById("profilePic");

    // Show the profile picture if available
    if (userData.photoURL) {
      profilePicElement.innerHTML = `<img src="${userData.photoURL}" alt="" style="width: 100%; height: 100%; border-radius: 50%;">`;
    } else {
      // Otherwise, show the first letter of the name
      const firstLetter = userData.displayName.charAt(0).toUpperCase();
      profilePicElement.innerHTML = firstLetter;
    }
  }

  document.getElementById("confirmForm").addEventListener("submit", function (event) {
    event.preventDefault();
    const formData = {
      uid: document.getElementById("uid").value,
      displayName: document.getElementById("name").value,
      email: document.getElementById("email").value,
      phone: document.getElementById("phone").value,
      address: document.getElementById("address").value,
      photoURL: userData.photoURL || ""
    };

    fetch("", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData)
    })
    .then(response => response.json())
    .then(data => {
      if (data.status === "success") {
        window.location.href = "../directives/dashboard.php";
      } else {
        alert("Error saving data. Please try again.");
      }
    })
    .catch(error => console.error("Error:", error));
  });
});

  </script>
</body>
</html>
