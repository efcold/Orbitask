<?php
ob_start();
session_start();

// Redirect if not logged in
if (!isset($_SESSION["uid"])) {
    header("Location: ../auth/login.php");
    exit();
}
$currentUserEmail = $_SESSION['email'] ?? '';
$uid = $_SESSION['uid'];
$planId = $_GET['plan_id'] ?? null; // Get plan ID from URL
$ownerUid = $_GET['owner_uid'] ?? null;

// Firebase SDK bootstrap
require __DIR__ . '/../vendor/autoload.php';
use Kreait\Firebase\Factory;

$factory = (new Factory)
    ->withServiceAccount(__DIR__ . '/../ms-digitalplanner-firebase-adminsdk-fbsvc-dc1c731d47.json')
    ->withDatabaseUri('https://ms-digitalplanner-default-rtdb.firebaseio.com/');
$database = $factory->createDatabase();

// Reference to the specific plan
$plansRef = "users/{$ownerUid}/plans/{$planId}";
function sanitizeEmail(string $email): string {
  return str_replace(['.', '#', '$', '[', ']'], '_', $email);
}
$myEmailKey = sanitizeEmail($currentUserEmail);
// Fetch plan details
$plan = $database->getReference($plansRef)->getValue();
$isOwner = isset($plan['creator']) && ($plan['creator'] === $uid);
if (!$plan) {
    die("Plan not found.");
}
// 2) Add Note with Mentions (Unified Handler)
if (isset($_POST['add_note'])) {
    $planId   = $_POST['plan_id'];
    $noteText = trim($_POST['note_text']);
    // Use provided owner_uid if available; otherwise, use the current user’s UID.
    $targetUid = isset($_POST['owner_uid']) && !empty($_POST['owner_uid']) ? $_POST['owner_uid'] : $uid;

    if (!empty($noteText)) {
        $noteRef = $database->getReference("users/{$targetUid}/plans/{$planId}/notes")->push();
        $noteRef->set([
            'author'    => $currentUserEmail,
            'text'      => htmlspecialchars($noteText),
            'timestamp' => time(),
        ]);
    }
    $viewUrl ="viewinvplans.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($ownerUid);

    // Redirect the user to the view plan page
    header("Location: " . $viewUrl);
    exit();
}
require __DIR__ . '/../handlers/plans/vip.php';
require __DIR__ . '/../handlers/plans/fetchplans.php';
if (isset($planId, $ownerUid)) {
  $filteredInvitedPlans = array_filter($invitedPlans, function($plan) use ($planId, $ownerUid) {
      return $plan['plan_id'] === $planId && $plan['owner'] === $ownerUid;
  });
  $plan = !empty($filteredInvitedPlans) ? reset($filteredInvitedPlans) : null;
} else {
  $plan = null;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="../assets/css/sidebar.css">
  <link rel="stylesheet" href="../assets/css/navbar.css">
  <link rel="stylesheet" href="../assets/css/invites.css">
  <title>Plan Details</title>
  <script>
  function openTab(evt, tabName) {
  let i, tabcontent, tablinks;
  
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
}
  </script>
</head>
<body>

<div class="navbar">
<div class="navbar-left">
  <button class="hamburger" onclick="toggleSidebar()">☰</button>
  <img src="../assets/img/icons/logo.png" alt="Logo" class="logo-image">
  <span class="logo-text">Digital Planner</span>
</div>
<div class="navbar-right">
    <button class="create-plan-btn" onclick="openPopup()">
      <img src="../assets/img/icons/plusicon.png" alt="" class="plus-icon">
    </button>
    <img id="profilePic" src="" alt="" class="profile-pic">
  </div>
  </div>

  <div class="sidebar">
  <a href="dashboard.php"><img src="../assets/img/icons/homeicon.png" alt="" class="sidebar-icon">Home</a>
  <a href="calendar.php"><img src="../assets//img/icons/calendaricon.png" alt="" class="sidebar-icon">Calendar</a>
  <a href="archive.php"><img src="../assets//img/icons/archive-icon.png" alt="" class="sidebar-icon">Archive</a>
  <a href=""><img src="../assets//img/icons/settingsicon.png" alt="" class="sidebar-icon">Settings</a>
  <a href="../auth/logout.php">Logout</a>
</div>

  <!-- Main Content Area -->
  <div class="navbar-content">
  <div class="navbar-tabs">
      <a href="#" class="tablinks active" onclick="openTab(event, 'Cards')">Discussion Board</a>
      <a href="#" class="tablinks" onclick="openTab(event, 'Tasks')">Tasks</a>
      </div>
      <div>
  
      <div class="main-content">
  <ul>
    <?php if ($plan): ?>
      <div class="plan-item-banner">
        <!-- Left Section: Lower Left -->
        <div class="banner-left">
          <h4 class="plan-title"><?= htmlspecialchars($plan['title'] ?? 'Untitled') ?></h4>
          <p class="plan-status"><strong>Status:</strong> <?= htmlspecialchars($plan['status'] ?? 'In Progress') ?></p>
          <p class="plan-role"><strong>Your Role:</strong> <?= htmlspecialchars($plan['invited_role'] ?? '') ?></p>
        </div>
        <!-- Right Section: Upper Right & Lower Right -->
        <div class="banner-right">
          <div class="banner-right-top">
            <p><strong>Start Date:</strong> <?= htmlspecialchars($plan['start_date'] ?? '—') ?></p>
            <p><strong>End Date:</strong> <?= htmlspecialchars($plan['end_date'] ?? '—') ?></p>
          </div>
          <div class="banner-right-bottom">
            <p><strong>Date:</strong> <?= htmlspecialchars($plan['date'] ?? '—') ?></p>
            <p><strong>Time:</strong> <?= htmlspecialchars($plan['time'] ?? '—') ?></p>
            <p><strong>Notes:</strong> <?= is_string($plan['notes'] ?? null) ? htmlspecialchars($plan['notes']) : '—' ?></p>
          </div>
        </div>
    </div>
    <div id="Cards" class="tabcontent" style="display:block;">
    <h2>Discussion Board</h2>
    <p>Here you can discuss plans and updates.</p>
    <div class="card-container">
    <div class="card">
            <!-- Accepted invitation: display announcements, notes, tasks, etc. -->
            <h4>Announcements</h4>
            <ul>
              <?php if (!empty($plan['announcements']) && is_array($plan['announcements'])): ?>
                <?php foreach ($plan['announcements'] as $announcement): ?>
                  <li>
                    <?= htmlspecialchars($announcement['text']) ?>
                    <em>(Posted on: <?= date('Y-m-d H:i', $announcement['timestamp']) ?>)</em>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li>No announcements yet.</li>
              <?php endif; ?>
            </ul>
            <div class="card">
            <h4>Notes</h4>
            <ul>
              <?php if (!empty($plan['notes']) && is_array($plan['notes'])): ?>
                <?php foreach ($plan['notes'] as $note): ?>
                  <li>
                    <strong><?= htmlspecialchars($note['author']) ?>:</strong>
                    <?= htmlspecialchars($note['text']) ?>
                    <em>(Posted on: <?= date('Y-m-d H:i', $note['timestamp']) ?>)</em>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li>No notes yet.</li>
              <?php endif; ?>
            </ul>
            <!-- Form to Add Note for Accepted Invitations -->
            <form method="POST">
              <input type="hidden" name="plan_id" value="<?= htmlspecialchars($plan['plan_id']) ?>">
              <input type="hidden" name="owner_uid" value="<?= htmlspecialchars($plan['owner']) ?>">
              <textarea name="note_text" placeholder="Add a note..." required></textarea><br>
              <button type="submit" name="add_note">Add Note</button>
            </form>
            </div>
              </div>
              </div>
              </div>
              <div id="Tasks" class="tabcontent">   
          <h2>Tasks</h2>
          <p>Manage your tasks here.</p>
            <ul>
              <?php if (!empty($plan['tasks'])): foreach ($plan['tasks'] as $taskId => $task): ?>
                <li>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
                    <input type="hidden" name="owner_uid" value="<?= $uid ?>">
                    <input type="hidden" name="task_id" value="<?= $taskId ?>">

                    <!-- Always send this field so $_POST['toggle_task'] exists -->
                    <input type="hidden" name="toggle_task" value="1">

                    <input type="checkbox" onchange="this.form.submit()"
                            <?= !empty($task['completed']) ? 'checked' : '' ?>>
                    <?= htmlspecialchars($task['name']) ?>
                    </form>
                </li>
              <?php endforeach; else: ?>
                <p>No tasks available.</p>
              <?php endif; ?>
            </ul>
          
          
        </li>
      <?php else: ?>
        <p>No pending invitations available.</p>
        <!-- Leave Plan -->
      <?php endif; ?>
    </ul>

    <form method="POST" onsubmit="return confirm('Are you sure you want to leave this plan?');">
  <input type="hidden" name="plan_id" value="<?= htmlspecialchars($plan['plan_id']) ?>">
  <input type="hidden" name="owner_uid" value="<?= htmlspecialchars($plan['owner']) ?>">
  <input type="hidden" name="invite_key" value="<?= htmlspecialchars($plan['invite_key']) ?>">
  <button type="submit" name="leave_plan" style="color: red;">Leave Plan</button>
</form>
</div>
</div></div>

</body>
</html>
