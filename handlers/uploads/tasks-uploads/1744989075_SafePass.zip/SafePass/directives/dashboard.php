<?php
ob_start();
session_start();

if (!isset($_SESSION["uid"])) {
    header("Location: ../auth/login.php");
    exit();
}

$currentUserEmail = $_SESSION['email'] ?? '';
$uid = $_SESSION['uid'];
// Check if photoURL exists in the fetched data
$photoURL = $userData['photoURL'] ?? '';  // Use a fallback if photoURL is not available

// Store photoURL in session if needed
$_SESSION['photoURL'] = $photoURL;
require __DIR__ . '/../vendor/autoload.php';
use Kreait\Firebase\Factory;

$factory = (new Factory)
    ->withServiceAccount(__DIR__ . '/../ms-digitalplanner-firebase-adminsdk-fbsvc-dc1c731d47.json')
    ->withDatabaseUri('https://ms-digitalplanner-default-rtdb.firebaseio.com/');
$database = $factory->createDatabase();

$plansRef = "users/{$uid}/plans/";
$myPlansRaw = $database->getReference($plansRef)->getValue() ?? [];
function sanitizeEmail(string $email): string {
    return str_replace(['.', '#', '$', '[', ']'], '_', $email);
}
$myEmailKey = sanitizeEmail($currentUserEmail);
$myPlans = [];
foreach ($myPlansRaw as $planId => $plan) {
    if (!empty($plan['title']) && !empty($plan['date'])) {
        $plan['plan_id'] = $planId;
        $myPlans[] = $plan;
    }
}
$plansByDate = [];
foreach ($myPlans as $plan) {
    $date = $plan['date'];
    if (!isset($plansByDate[$date])) {
        $plansByDate[$date] = [];
    }
    $plansByDate[$date][] = $plan;
}
$year  = date("Y");
$month = date("m");
$numDays = cal_days_in_month(CAL_GREGORIAN, $month, $year);

$firstDayOfMonth = strtotime("$year-$month-01");
$firstWeekday = date("w", $firstDayOfMonth);

require __DIR__ . '/../handlers/dashboard/create.php';
require __DIR__ . '/../handlers/plans/fetchplans.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="../assets/css/sidebar.css">
  <link rel="stylesheet" href="../assets/css/navbar.css">
  <link rel="stylesheet" href="../assets/css/dashboard.css">
  <link rel="stylesheet" href="../assets/css/create.css">
  <link rel="stylesheet" href="../assets/css/calendar.css">
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Sans+Text:wght@400;500;700">
  <script src="../assets/js/main.js"></script>
  <script src="../assets/js/togglesidebar.js"></script>
  <title>Digital Planner Dashboard</title>

</head>
<body>

<div class="navbar">
<div class="navbar-left">
  <button class="hamburger" onclick="toggleSidebar()">☰</button>
  <img src="../assets/img/icons/logo.png" alt="Logo" class="logo-image">
  <span class="logo-text">Digital Planner</span>
</div>
<div class="navbar-right">
    <button class="create-plan-btn" onclick="openPopup()">
      <img src="../assets/img/icons/plusicon.png" alt="" class="plus-icon">
    </button>
    <img id="profilePic" src="" alt="" class="profile-pic">
  </div>
  </div>

<div class="sidebar">
  <a href="dashboard.php"><img src="../assets/img/icons/homeicon.png" alt="" class="sidebar-icon">Home</a>
  <a href="calendar.php"><img src="../assets//img/icons/calendaricon.png" alt="" class="sidebar-icon">Calendar</a>
  <a href="archive.php"><img src="../assets//img/icons/archive-icon.png" alt="" class="sidebar-icon">Archive</a>
  <a href=""><img src="../assets//img/icons/settingsicon.png" alt="" class="sidebar-icon">Settings</a>
  <a href="../auth/logout.php">Logout</a>
</div>


<div class="main-content">
  <div class="dashboard-container">

    <div class="cards-container">
      <div class="cards-container">
        <h3 class="section-title">My Plans</h3>
        <hr>
        <div class="card-container">
          <?php if ($myPlans): foreach ($myPlans as $planId => $plan):
            if (empty($plan['title'])) continue;
            $creator = $currentUserEmail;
            $status = $plan['status'] ?? 'In Progress';
            $date = $plan['date'] ?? '—';
            $viewUrl = "viewplan.php?plan_id=" . urlencode($planId) . "&owner_uid=" . urlencode($uid);
          ?>
            <div class="card" onclick="window.location.href='<?= $viewUrl ?>'">
              <h3><?= htmlspecialchars($plan['title']) ?></h3>
              <p><strong>Status:</strong> <?= htmlspecialchars($status) ?></p>
              <p><strong>Creator:</strong> <?= htmlspecialchars($creator) ?></p>
            </div>
          <?php endforeach; else: ?>
            <p>No plans available.</p>
          <?php endif; ?>
        </div>
        
        <h3 class="section-title">Shared Plans</h3>
        <hr>
        <div class="card-container">
          <?php if ($invitedPlans): foreach ($invitedPlans as $plan):
            $creator = $plan['owner'];
            $status = $plan['status'] ?? 'In Progress';
            $date = $plan['date'] ?? '—';
            $isAccepted = !empty($plan['accepted']);
            $viewUrl = "invites.php?plan_id=" . urlencode($plan['plan_id']) . "&owner_uid=" . urlencode($plan['owner']);?>
            <?php if ($isAccepted): ?>
              <div class="card" onclick="window.location.href='<?= $viewUrl ?>'">
                <h3><?= htmlspecialchars($plan['title'] ?? 'Untitled') ?></h3>
                <p><strong>Status:</strong> <span><?= htmlspecialchars($status) ?></span></p>
                <p><strong>Creator:</strong> <span><?= htmlspecialchars($creator) ?></span></p>
              </div>
            <?php else: ?>
              <div class="card">
                <h3><?= htmlspecialchars($plan['title'] ?? 'Untitled') ?></h3>
                <p><strong>Status:</strong> <span><?= htmlspecialchars($status) ?></span></p>
                <p><strong>Creator:</strong> <span><?= htmlspecialchars($creator) ?></span></p>
                <div class="card-inner-buttons">
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="invite_key" value="<?= htmlspecialchars($plan['invite_key']) ?>">
                  <input type="hidden" name="plan_id" value="<?= htmlspecialchars($plan['plan_id']) ?>">
                  <input type="hidden" name="owner_uid" value="<?= htmlspecialchars($plan['owner']) ?>">
                  <button type="submit" name="accept_invite">Accept</button>
                </form>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="invite_key" value="<?= htmlspecialchars($plan['invite_key']) ?>">
                  <button type="submit" name="ignore_invite">Ignore</button>
                </form>
            </div>
              </div>
            <?php endif; ?>
          <?php endforeach; else: ?>
            <p>No invitations available.</p>
          <?php endif; ?>
        </div>
      </div>
    </div>
<!--   <div class="calendar-container">
      <h2>Calendar</h2>
      <div id="calendar"></div>
    </div> -->
  </div>
</div>
  
<!-- Popup Overlay -->
<div id="popupOverlay" class="hidden"></div>

<!-- Popup Form -->
<div id="popupForm" class="popup">
  <h3>Create a New Plan</h3>
  <form method="POST">
    <div class="form-group">
      <label for="planTitle">Title:</label>
      <input type="text" id="planTitle" name="title" required>
    </div>
    <div class="form-group">
      <label for="startDate">Start Date:</label>
      <input type="date" id="startDate" name="start_date" required>
    </div>
    <div class="form-group">
      <label for="endDate">End Date:</label>
      <input type="date" id="endDate" name="end_date" required>
    </div>
    <div class="form-group task-group">
      <label>Tasks:</label>
      <div class="task-inputs">
        <input type="text" id="newTask" placeholder="Task name">
        <input type="date" id="taskDueDate">
        <input type="time" id="taskDueTime">
        <button type="button" onclick="addTask()">Add Task</button>
      </div>
      <ul id="taskList"></ul>
    </div>
    <input type="hidden" name="tasks_json" id="tasks_json" value="">
    <div class="button-group">
      <button type="submit" name="create_plan" class="btn btn-primary">Create Plan</button>
      <button type="button" onclick="closePopup()" class="btn btn-secondary">Close</button>
    </div>
  </form>
</div>


<script src="../assets/js/calendar.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
</body>
</html>

