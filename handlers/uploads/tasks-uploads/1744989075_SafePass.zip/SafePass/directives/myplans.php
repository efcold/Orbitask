<?php
ob_start();
session_start();

// Redirect if not logged in
if (!isset($_SESSION["uid"])) {
    header("Location: ../auth/login.php");
    exit();
}

$currentUserEmail = $_SESSION['email'] ?? '';
$uid = $_SESSION['uid'];

// Firebase SDK bootstrap
require __DIR__ . '/../vendor/autoload.php';
use Kreait\Firebase\Factory;

$factory = (new Factory)
    ->withServiceAccount(__DIR__ . '/../ms-digitalplanner-firebase-adminsdk-fbsvc-dc1c731d47.json')
    ->withDatabaseUri('https://ms-digitalplanner-default-rtdb.firebaseio.com/');
$database = $factory->createDatabase();

// Reference to the owner’s plans node
$plansRef = "users/{$uid}/plans/";

// Helper to sanitize emails into Firebase keys
function sanitizeEmail(string $email): string {
    return str_replace(['.', '#', '$', '[', ']'], '_', $email);
}
$myEmailKey = sanitizeEmail($currentUserEmail);

// Include handlers and fetching scripts
require __DIR__ . '/../handlers/plans/handlers.php';
require __DIR__ . '/../handlers/plans/fetchplans.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="../assets/css/sidebar.css">
  <link rel="stylesheet" href="../assets/css/navbar.css">
  <script src="../assets/js/myplans/main.js"></script>
  <title>Digital Planner</title>
</head>
<body>
  <!-- Sidebar Navigation -->
  <div class="sidebar">
  <a href="dashboard.php"><img src="../assets/img/icons/homeicon.png" alt="" class="sidebar-icon">Home</a>
  <a href="calendar.php"><img src="../assets//img/icons/calendaricon.png" alt="" class="sidebar-icon">Calendar</a>
  <a href=""><img src="../assets//img/icons/archive-icon.png" alt="" class="sidebar-icon">Archive</a>
  <a href=""><img src="../assets//img/icons/settingsicon.png" alt="" class="sidebar-icon">Settings</a>
  <a href="../auth/logout.php">Logout</a>
</div>

  
  <!-- Main Content Area -->
  <div class="main-content">
    <h2>Welcome to Your Digital Planner</h2>
    <button onclick="openPopup()">Create Plan</button>

    <!-- Create Plan Popup -->
    <div id="popupForm">
      <h3>Create a New Plan</h3>
      <form method="POST">
        <label>Date:</label>
        <input type="date" name="date" required><br>
        <label>Time:</label>
        <input type="time" name="time" required><br>
        <label>Title:</label>
        <input type="text" name="title" required><br>
        <label>Notes:</label>
        <textarea name="notes"></textarea><br>
        <!-- New: Start and End Dates for the project -->
        <label>Start Date:</label>
        <input type="date" name="start_date" required><br>
        <label>End Date:</label>
        <input type="date" name="end_date" required><br>
        <label>Tasks:</label>
        <input type="text" id="newTask" placeholder="Task name">
        <button type="button" onclick="addTask()">Add Task</button>
        <ul id="taskList"></ul>
        <input type="hidden" name="tasks_json" id="tasks_json" value="">
        <button type="submit" name="create_plan">Save Plan</button>
        <button type="button" onclick="closePopup()">Close</button>
      </form>
    </div>

    <!-- Owner’s Plans -->
    <h3>Your Plans</h3>
    <ul>
      <?php if ($myPlans): foreach ($myPlans as $planId => $plan):
        if (empty($plan['tasks']) && empty($plan['title'])) continue;
        $isOwner = ($plan['creator'] === $uid);
      ?>
        <li>
          <h4><?= htmlspecialchars($plan['title'] ?? 'Untitled') ?></h4>
          <p>Date: <?= htmlspecialchars($plan['date'] ?? '—') ?></p>
          <p>Time: <?= htmlspecialchars($plan['time'] ?? '—') ?></p>
          <p>Start Date: <?= htmlspecialchars($plan['start_date'] ?? '—') ?></p>
          <p>End Date: <?= htmlspecialchars($plan['end_date'] ?? '—') ?></p>
          <p>Notes: 
            <?= is_string($plan['notes'] ?? null) ? htmlspecialchars($plan['notes']) : '—' ?>
          </p>
          
          <!-- Status Dropdown -->
          <form method="POST" style="display:inline;">
            <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
            <input type="hidden" name="update_status" value="1">
            <select name="status" onchange="this.form.submit()">
              <option value="In Progress" <?= (isset($plan['status']) && $plan['status'] === "In Progress") ? "selected" : "" ?>>In Progress</option>
              <option value="Completed" <?= (isset($plan['status']) && $plan['status'] === "Completed") ? "selected" : "" ?>>Completed</option>
            </select>
          </form>
          
          <!-- Display Announcements -->
          <h4>Announcements</h4>
          <ul>
            <?php if (!empty($plan['announcements']) && is_array($plan['announcements'])): ?>
              <?php foreach ($plan['announcements'] as $announcement): ?>
                <li>
                  <?= htmlspecialchars($announcement['text']) ?>
                  <em>(Posted on: <?= date('Y-m-d H:i', $announcement['timestamp']) ?>)</em>
                </li>
              <?php endforeach; ?>
            <?php else: ?>
              <li>No announcements yet.</li>
            <?php endif; ?>
          </ul>
          <!-- Form to Add Announcement -->
          <form method="POST">
            <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
            <textarea name="announcement_text" placeholder="Write an announcement..." required></textarea><br>
            <button type="submit" name="add_announcement">Post Announcement</button>
          </form>
          
          <!-- Display Notes -->
          <h4>Notes</h4>
          <ul>
            <?php if (!empty($plan['notes']) && is_array($plan['notes'])): ?>
              <?php foreach ($plan['notes'] as $note): ?>
                <li>
                  <strong><?= htmlspecialchars($note['author']) ?>:</strong>
                  <?= htmlspecialchars($note['text']) ?>
                  <em>(Posted on: <?= date('Y-m-d H:i', $note['timestamp']) ?>)</em>
                </li>
              <?php endforeach; ?>
            <?php else: ?>
              <li>No notes yet.</li>
            <?php endif; ?>
          </ul>
          <!-- Form to Add Note (for Creator) -->
          <?php if ($isOwner): ?>
          <form method="POST">
            <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
            <textarea name="note_text" placeholder="Add a note..." required></textarea><br>
            <button type="submit" name="add_note">Add Note</button>
          </form>
          <?php endif; ?>
          
          <!-- Add Task and Invite Collaborator if Owner -->
          <?php if ($isOwner): ?>
            <!-- Add Task -->
            <form method="POST">
              <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
              <input type="text" name="task_name" placeholder="New Task" required>
              <button type="submit" name="add_task">Add Task</button>
            </form>
            <!-- Invite Collaborator -->
            <form method="POST">
              <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
              <input type="email" name="invite_email" placeholder="Invite collaborator" required>
              <select name="invite_role">
                <option value="collaborator" selected>Collaborator</option>
                <option value="assistant admin">Assistant Admin</option>
              </select>
              <button type="submit" name="invite_user">Invite</button>
            </form>
          <?php endif; ?>

          <!-- Toggle Tasks -->
          <ul>
            <?php if (!empty($plan['tasks'])): foreach ($plan['tasks'] as $taskId => $task): ?>
              <li>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
                <input type="hidden" name="owner_uid" value="<?= $uid ?>">
                <input type="hidden" name="task_id" value="<?= $taskId ?>">

                <!-- Always send this field so $_POST['toggle_task'] exists -->
                <input type="hidden" name="toggle_task" value="1">

                <input type="checkbox" onchange="this.form.submit()"
                      <?= !empty($task['completed']) ? 'checked' : '' ?>>
                <?= htmlspecialchars($task['name']) ?>
              </form>

              </li>
            <?php endforeach; else: ?>
              <p>No tasks available.</p>
            <?php endif; ?>
          </ul>
        </li>
      <?php endforeach; else: ?>
        <p>No plans available.</p>
      <?php endif; ?>
    </ul>

    <!-- Invited Plans / Invitations -->
    <h3>Invitations</h3>
    <ul>
      <?php if ($invitedPlans): foreach ($invitedPlans as $plan): ?>
        <li>
          <h4><?= htmlspecialchars($plan['title'] ?? 'Untitled') ?></h4>
          <p>Date: <?= htmlspecialchars($plan['date'] ?? '—') ?></p>
          <p>Time: <?= htmlspecialchars($plan['time'] ?? '—') ?></p>
          <p>Start Date: <?= htmlspecialchars($plan['start_date'] ?? '—') ?></p>
          <p>End Date: <?= htmlspecialchars($plan['end_date'] ?? '—') ?></p>
          <p>Notes: <?= is_string($plan['notes'] ?? null) ? htmlspecialchars($plan['notes']) : '—' ?></p>
          <p>Status: <?= htmlspecialchars($plan['status'] ?? 'In Progress') ?></p>
          <p>Your Role: <?= htmlspecialchars($plan['invited_role']) ?></p>
          
          <?php if (empty($plan['accepted'])): ?>
            <!-- Invitation pending: show Accept/Ignore buttons -->
            <form method="POST" style="display:inline;">
              <input type="hidden" name="invite_key" value="<?= htmlspecialchars($plan['invite_key']) ?>">
              <input type="hidden" name="plan_id" value="<?= htmlspecialchars($plan['plan_id']) ?>">
              <input type="hidden" name="owner_uid" value="<?= htmlspecialchars($plan['owner']) ?>">
              <button type="submit" name="accept_invite">Accept Invitation</button>
            </form>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="invite_key" value="<?= htmlspecialchars($plan['invite_key']) ?>">
              <button type="submit" name="ignore_invite">Ignore Invitation</button>
            </form>
          <?php else: ?>
            <!-- Accepted invitation: display announcements, notes, tasks, etc. -->
            <h4>Announcements</h4>
            <ul>
              <?php if (!empty($plan['announcements']) && is_array($plan['announcements'])): ?>
                <?php foreach ($plan['announcements'] as $announcement): ?>
                  <li>
                    <?= htmlspecialchars($announcement['text']) ?>
                    <em>(Posted on: <?= date('Y-m-d H:i', $announcement['timestamp']) ?>)</em>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li>No announcements yet.</li>
              <?php endif; ?>
            </ul>
            <h4>Notes</h4>
            <ul>
              <?php if (!empty($plan['notes']) && is_array($plan['notes'])): ?>
                <?php foreach ($plan['notes'] as $note): ?>
                  <li>
                    <strong><?= htmlspecialchars($note['author']) ?>:</strong>
                    <?= htmlspecialchars($note['text']) ?>
                    <em>(Posted on: <?= date('Y-m-d H:i', $note['timestamp']) ?>)</em>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li>No notes yet.</li>
              <?php endif; ?>
            </ul>
            <!-- Form to Add Note for Accepted Invitations -->
            <form method="POST">
              <input type="hidden" name="plan_id" value="<?= htmlspecialchars($plan['plan_id']) ?>">
              <input type="hidden" name="owner_uid" value="<?= htmlspecialchars($plan['owner']) ?>">
              <textarea name="note_text" placeholder="Add a note..." required></textarea><br>
              <button type="submit" name="add_note">Add Note</button>
            </form>
            <!-- Toggle Tasks for Accepted Invitations -->
            <ul>
              <?php if (!empty($plan['tasks'])): foreach ($plan['tasks'] as $taskId => $task): ?>
                <li>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
                    <input type="hidden" name="owner_uid" value="<?= $uid ?>">
                    <input type="hidden" name="task_id" value="<?= $taskId ?>">

                    <!-- Always send this field so $_POST['toggle_task'] exists -->
                    <input type="hidden" name="toggle_task" value="1">

                    <input type="checkbox" onchange="this.form.submit()"
                          <?= !empty($task['completed']) ? 'checked' : '' ?>>
                    <?= htmlspecialchars($task['name']) ?>
                  </form>
                </li>
              <?php endforeach; else: ?>
                <p>No tasks available.</p>
              <?php endif; ?>
            </ul>
          <?php endif; ?>
        </li>
      <?php endforeach; else: ?>
        <p>No pending invitations available.</p>
      <?php endif; ?>
    </ul>

  </div>
</body>
</html>
