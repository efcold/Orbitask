<?php
ob_start();
session_start();

// Redirect if not logged in
if (!isset($_SESSION["uid"])) {
    header("Location: ../auth/login.php");
    exit();
}

$currentUserEmail = $_SESSION['email'] ?? '';
$uid = $_SESSION['uid'];

// Firebase SDK bootstrap
require __DIR__ . '/../vendor/autoload.php';
use Kreait\Firebase\Factory;

$factory = (new Factory)
    ->withServiceAccount(__DIR__ . '/../ms-digitalplanner-firebase-adminsdk-fbsvc-dc1c731d47.json')
    ->withDatabaseUri('https://ms-digitalplanner-default-rtdb.firebaseio.com/');
$database = $factory->createDatabase();

// Reference to the owner’s plans node
$plansRef = "users/{$uid}/plans/";

// Helper to sanitize emails into Firebase keys
function sanitizeEmail(string $email): string {
    return str_replace(['.', '#', '$', '[', ']'], '_', $email);
}

$myEmailKey = sanitizeEmail($currentUserEmail);
// Include handlers and fetchers (fetches $myPlans and $invitedPlans)
require __DIR__ . '/../handlers/plans/vip.php';
require __DIR__ . '/../handlers/plans/fetchplans.php';

// Build a mapping of date => plans for quick lookup in FullCalendar (using owner's plans only)
$plansByDate = [];
foreach ($myPlans as $plan) {
    if (!empty($plan['date'])) {
        $date = $plan['date'];
        if (!isset($plansByDate[$date])) {
            $plansByDate[$date] = [];
        }
        $plansByDate[$date][] = $plan;
    }
}

// Get current year and month for display (navigation can be added later)
$year  = date("Y");
$month = date("m");
$numDays = cal_days_in_month(CAL_GREGORIAN, $month, $year);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="../assets/css/sidebar.css">
  <link rel="stylesheet" href="../assets/css/navbar.css">
  <link rel="stylesheet" href="../assets/css/calendar.css">
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet" />
  <title>Digital Planner Dashboard</title>
</head>
<body>
<div class="navbar">
<div class="navbar-left">
  <button class="hamburger" onclick="toggleSidebar()">☰</button>
  <img src="../assets/img/icons/logo.png" alt="Logo" class="logo-image">
  <span class="logo-text">Digital Planner</span>
</div>
<div class="navbar-right">
    <button class="create-plan-btn" onclick="openPopup()">
      <img src="../assets/img/icons/plusicon.png" alt="" class="plus-icon">
    </button>
    <img id="profilePic" src="" alt="" class="profile-pic">
  </div>
  </div>
  <div class="sidebar">
  <a href="dashboard.php"><img src="../assets/img/icons/homeicon.png" alt="" class="sidebar-icon">Home</a>
  <a href="calendar.php"><img src="../assets//img/icons/calendaricon.png" alt="" class="sidebar-icon">Calendar</a>
  <a href="archive.php"><img src="../assets//img/icons/archive-icon.png" alt="" class="sidebar-icon">Archive</a>
  <a href=""><img src="../assets//img/icons/settingsicon.png" alt="" class="sidebar-icon">Settings</a>
  <a href="../auth/logout.php">Logout</a>
</div>



<div class="main-content">
  <div class="content-wrapper">
    <!-- Calendar Section -->
    <div class="calendar-section">
      <h2>Dashboard Calendar</h2>
      <div id="calendar"></div>
    </div>
  </div>
</div>
<script src="../assets/js/calendar.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
</body>
</html>
