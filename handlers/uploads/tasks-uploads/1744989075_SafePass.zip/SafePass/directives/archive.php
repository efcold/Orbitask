<?php
ob_start();
session_start();

if (!isset($_SESSION["uid"])) {
    header("Location: ../auth/login.php");
    exit();
}

$currentUserEmail = $_SESSION['email'] ?? '';
$uid = $_SESSION['uid'];
// Check if photoURL exists in the fetched data
$photoURL = $userData['photoURL'] ?? '';  // Use a fallback if photoURL is not available

// Store photoURL in session if needed
$_SESSION['photoURL'] = $photoURL;
require __DIR__ . '/../vendor/autoload.php';
use Kreait\Firebase\Factory;

$factory = (new Factory)
    ->withServiceAccount(__DIR__ . '/../ms-digitalplanner-firebase-adminsdk-fbsvc-dc1c731d47.json')
    ->withDatabaseUri('https://ms-digitalplanner-default-rtdb.firebaseio.com/');
$database = $factory->createDatabase();
function sanitizeEmail(string $email): string {
    return str_replace(['.', '#', '$', '[', ']'], '_', $email);
}

$myEmailKey = sanitizeEmail($currentUserEmail);
$plansRef = "users/{$uid}/plans/";
$myPlansRaw = $database->getReference($plansRef)->getValue() ?? [];
$myPlans = [];
foreach ($myPlansRaw as $planId => $plan) {
    if (!empty($plan['title']) && !empty($plan['date'])) {
        $plan['plan_id'] = $planId;
        $myPlans[] = $plan;
    }
}
// Retrieve invitations that were ignored for the current user
// Option 1. If your Firebase rules and query support it you can use an orderByChild query:
$ignoredInvitations = $database->getReference("invitations/{$myEmailKey}")
    ->orderByChild("ignored")
    ->equalTo(true)
    ->getValue();


require __DIR__ . '/../handlers/dashboard/create.php';
require __DIR__ . '/../handlers/plans/fetchplans.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="../assets/css/sidebar.css">
  <link rel="stylesheet" href="../assets/css/navbar.css">
  <link rel="stylesheet" href="../assets/css/dashboard.css">
  <link rel="stylesheet" href="../assets/css/create.css">
  <link rel="stylesheet" href="../assets/css/calendar.css">
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Sans+Text:wght@400;500;700">
  <script src="../assets/js/main.js"></script>
  <script src="../assets/js/togglesidebar.js"></script>
  <title>Digital Planner Dashboard</title>

</head>
<body>

<div class="navbar">
<div class="navbar-left">
  <button class="hamburger" onclick="toggleSidebar()">☰</button>
  <img src="../assets/img/icons/logo.png" alt="Logo" class="logo-image">
  <span class="logo-text">Digital Planner</span>
</div>
<div class="navbar-right">
    <button class="create-plan-btn" onclick="openPopup()">
      <img src="../assets/img/icons/plusicon.png" alt="" class="plus-icon">
    </button>
    <img id="profilePic" src="" alt="" class="profile-pic">
  </div>
  </div>

<div class="sidebar">
  <a href="dashboard.php"><img src="../assets/img/icons/homeicon.png" alt="" class="sidebar-icon">Home</a>
  <a href="calendar.php"><img src="../assets//img/icons/calendaricon.png" alt="" class="sidebar-icon">Calendar</a>
  <a href=""><img src="../assets//img/icons/archive-icon.png" alt="" class="sidebar-icon">Archive</a>
  <a href=""><img src="../assets//img/icons/settingsicon.png" alt="" class="sidebar-icon">Settings</a>
  <a href="../auth/logout.php">Logout</a>
</div>

<div class="main-content">
  <h2>Ignored Invitations Archive</h2>
  <hr>
  <div class="card-container">
    <?php if (!empty($ignoredInvitations)): ?>
        <?php
            foreach ($ignoredInvitations as $inviteKey => $invitation):
                $planId   = $invitation['plan_id'] ?? '';
                $ownerUid = $invitation['owner'] ?? '';
                $status   = $invitation['status'] ?? 'In Progress';

                // Fetch the plan details using owner UID and plan ID
                $planRef = "users/{$ownerUid}/plans/{$planId}";
                $planData = $database->getReference($planRef)->getValue();
                $title = $planData['title'] ?? 'Untitled Plan';
            ?>

        <div class="card">
          <h3><?= htmlspecialchars($title) ?></h3>
          <p><strong>Status:</strong> <?= htmlspecialchars($status) ?></p>
          <p><strong>Creator:</strong> <?= htmlspecialchars($ownerUid) ?></p>

          <!-- Buttons to accept or ignore the invitation -->
          <div class="card-buttons">
            <form method="POST" action="archive.php">
              <input type="hidden" name="invite_key" value="<?= htmlspecialchars($inviteKey) ?>">
              <input type="hidden" name="plan_id"    value="<?= htmlspecialchars($planId) ?>">
              <input type="hidden" name="owner_uid"  value="<?= htmlspecialchars($ownerUid) ?>">
              <button type="submit" name="accept_invite" class="btn-accept">Accept</button>
              <button type="submit" name="ignore_invite" class="btn-ignore">Ignore</button>
            </form>
          </div>

      <?php endforeach; ?>
    <?php else: ?>
      <p>No ignored invitations found in your archive.</p>
    <?php endif; ?>
  </div>
</div>

</body>
</html>

