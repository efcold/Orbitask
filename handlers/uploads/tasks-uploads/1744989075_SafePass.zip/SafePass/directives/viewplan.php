<?php
ob_start();
session_start();

// Redirect if not logged in
if (!isset($_SESSION["uid"])) {
    header("Location: ../auth/login.php");
    exit();
}
$currentUserEmail = $_SESSION['email'] ?? '';
$uid = $_SESSION['uid'];
$planId = $_GET['plan_id'] ?? null; // Get plan ID from URL
$ownerUid = $_GET['owner_uid'] ?? null;

// Firebase SDK bootstrap
require __DIR__ . '/../vendor/autoload.php';
use Kreait\Firebase\Factory;

$factory = (new Factory)
    ->withServiceAccount(__DIR__ . '/../ms-digitalplanner-firebase-adminsdk-fbsvc-dc1c731d47.json')
    ->withDatabaseUri('https://ms-digitalplanner-default-rtdb.firebaseio.com/');
$database = $factory->createDatabase();

// Reference to the specific plan
$plansRef = "users/{$ownerUid}/plans/{$planId}";
function sanitizeEmail(string $email): string {
  return str_replace(['.', '#', '$', '[', ']'], '_', $email);
}
$myEmailKey = sanitizeEmail($currentUserEmail);
// Fetch plan details
$plan = $database->getReference($plansRef)->getValue();
$isOwner = isset($plan['creator']) && ($plan['creator'] === $uid);

if (!$plan) {
    die("Plan not found.");
}
require __DIR__ . '/../handlers/plans/vmp.php';
require __DIR__ . '/../handlers/plans/fetchplans.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="../assets/css/sidebar.css">
  <link rel="stylesheet" href="../assets/css/navbar.css">
  <link rel="stylesheet" href="../assets/css/viewplan.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Google+Sans+Text:wght@400;500;700">
  <script src="../assets/js/togglesidebar.js"></script>
  <script>
  function openTab(evt, tabName) {
  let i, tabcontent, tablinks;
  
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  
  document.getElementById(tabName).style.display = "block";
  evt.currentTarget.className += " active";
}
  </script>

<title>Plan Details</title>
</head>


<body>

<div class="navbar">
<div class="navbar-left">
  <button class="hamburger" onclick="toggleSidebar()">☰</button>
  <img src="../assets/img/icons/logo.png" alt="Logo" class="logo-image">
  <span class="logo-text">Digital Planner</span>
</div>
<div class="navbar-right">
    <button class="create-plan-btn" onclick="openPopup()">
      <img src="../assets/img/icons/plusicon.png" alt="" class="plus-icon">
    </button>
    <img id="profilePic" src="" alt="" class="profile-pic">
  </div>
  </div>

  <div class="sidebar">
  <a href="dashboard.php">
    <img src="../assets/img/icons/homeicon.png" alt="" class="sidebar-icon">Home
  </a>
  <a href="calendar.php">
    <img src="../assets/img/icons/calendaricon.png" alt="" class="sidebar-icon">Calendar
  </a>
  <a href="#" class="sidebar-item no-border non-clickable">
    <img src="../assets/img/icons/tasksicon.png" alt="" class="sidebar-icon">Tasks
  </a>

  <!-- Optional: Keep the calendar widget below if needed -->
  <div class="outer-card"> 
    <div class="calendar-navigation">
      <button class="calendar-button" id="prevMonth">&#8592;</button>
      <span id="calendarMonth">Loading...</span>
      <button class="calendar-button" id="nextMonth">&#8594;</button>
    </div>
    <div class="small-calendar" id="smallCalendar"></div>
  </div>

  <a href="archive.php"><img src="../assets//img/icons/archive-icon.png" alt="" class="sidebar-icon">Archive</a>
  <a href=""><img src="../assets//img/icons/settingsicon.png" alt="" class="sidebar-icon">Settings</a>
  <a href="../auth/logout.php">Logout</a>
</div>
</div>

  <!-- Main Content Area -->
  <div class="navbar-content">
  <div class="navbar-tabs">
      <a href="#" class="tablinks active" onclick="openTab(event, 'Cards')">Discussion Board</a>
      <a href="#" class="tablinks" onclick="openTab(event, 'Tasks')">Tasks</a>
      <a href="#" class="tablinks" onclick="openTab(event, 'Invites')">People</a>
      </div>
      <div>

  <div class="main-content">
  <div class="banner">
  <!-- Left Section: Lower Left -->
  <div class="banner-left">
    <h1 class="plan-title"><?= htmlspecialchars($plan['title'] ?? 'Untitled Plan') ?></h1>
    <p class="plan-status"><strong>Status:</strong> <?= htmlspecialchars($plan['status'] ?? 'In Progress') ?></p>
  </div>

  <!-- Right Section: Upper Right and Lower Right -->
  <div class="banner-right">
    <div class="banner-right-top">
      <p><strong>Start Date:</strong> <?= htmlspecialchars($plan['start_date'] ?? '—') ?></p>
      <p><strong>End Date:</strong> <?= htmlspecialchars($plan['end_date'] ?? '—') ?></p>
    </div>
    <div class="banner-right-bottom">
    <div class="info-dropdown-container">
  <button class="info-btn" onclick="toggleInfoDropdown()">i</button>
  <div id="infoDropdown" class="info-dropdown">
    <form method="POST">
      <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
      <input type="hidden" name="update_status" value="1">
      <label for="status">Status:</label>
      <select name="status" onchange="this.form.submit()">
        <option value="In Progress" <?= (isset($plan['status']) && $plan['status'] === "In Progress") ? "selected" : "" ?>>In Progress</option>
        <option value="Completed" <?= (isset($plan['status']) && $plan['status'] === "Completed") ? "selected" : "" ?>>Completed</option>
      </select>
    </form>
    <?php if ($isOwner): ?>
    <form method="POST" onsubmit="return confirm('Are you sure you want to delete this plan?');">
      <input type="hidden" name="delete_plan" value="1">
      <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
      <button type="submit" class="delete-btn">Delete Plan</button>
    </form>
    <?php endif; ?>
  </div>
</div>
    </div>
  </div>
</div>


     
    <div id="Cards" class="tabcontent" style="display:block;">
    <div class="card-container">
  <div class="card card-anno">
    <div class="card-header">
      <h4>Announcements</h4>
      <?php if ($isOwner): ?>
        <button class="open-popup-btn" onclick="openPopup('announcementPopup')">+ Create Announcement</button>
      <?php endif; ?>
    </div>
    <ul class="card-list">
      <?php if (!empty($plan['announcements']) && is_array($plan['announcements'])): ?>
        <?php foreach ($plan['announcements'] as $announcement): ?>
          <li>
            <p><?= htmlspecialchars($announcement['text']) ?></p>
            <em>Posted: <?= date('Y-m-d H:i', $announcement['timestamp']) ?></em>
          </li>
        <?php endforeach; ?>
      <?php else: ?>
        <li>No announcements yet.</li>
      <?php endif; ?>
    </ul>
  </div>

  <div class="card card-notes">
    <div class="card-header">
      <h4>Notes</h4>
      <?php if ($isOwner): ?>
        <button class="open-popup-btn" onclick="openPopup('notesPopup')">+ Add Note</button>
      <?php endif; ?>
    </div>
    <ul class="card-list">
      <?php if (!empty($plan['notes']) && is_array($plan['notes'])): ?>
        <?php foreach ($plan['notes'] as $note): ?>
          <li>
            <strong><?= htmlspecialchars($note['author']) ?>:</strong>
            <p><?= htmlspecialchars($note['text']) ?></p>
            <em>Posted: <?= date('Y-m-d H:i', $note['timestamp']) ?></em>
          </li>
        <?php endforeach; ?>
      <?php else: ?>
        <li>No notes yet.</li>
      <?php endif; ?>
    </ul>
  </div>
</div>

          </div>

   <!-- Add Task and Invite Collaborator if Owner -->
   <div id="Invites" class="tabcontent">
  <div class="tab-header">
    <h3>People</h3>
    <?php if ($isOwner): ?>
      <button class="open-popup-btn" onclick="openPopup('invitePopup')">+ Invite People</button>
      <button class="open-popup-btn" onclick="openPopup('pendingPopup')">View Pending Invites</button>
    <?php endif; ?>
  </div>

  <?php
    // Accepted collaborators
    $accepted = [];
    if (!empty($plan['invited']) && is_array($plan['invited'])) {
        foreach ($plan['invited'] as $emailKey => $status) {
            if ($status === 'accepted') {
                $accepted[] = $emailKey;
            }
        }
    }
  ?>

  <ul class="people-list">
    <?php if (!empty($accepted)): ?>
      <?php foreach ($accepted as $emailKey): ?>
        <li><?= htmlspecialchars(str_replace('_', '.', $emailKey)) ?></li>
      <?php endforeach; ?>
    <?php else: ?>
      <p>No collaborators have accepted yet.</p>
    <?php endif; ?>
  </ul>
</div>

<!-- Pending Invites Popup -->
<div class="popup" id="pendingPopup">
  <div class="popup-content">
    <span class="close-popup" onclick="closePopup('pendingPopup')">&times;</span>
    <h4>Pending Invites</h4>
    <?php
      // Pending invites (not accepted)
      $pending = [];
      if (!empty($plan['invited']) && is_array($plan['invited'])) {
          foreach ($plan['invited'] as $emailKey => $status) {
              if ($status !== 'accepted') {
                  $pending[$emailKey] = $status;
              }
          }
      }
    ?>
    <ul class="pending-list">
      <?php if (!empty($pending)): ?>
        <?php foreach ($pending as $emailKey => $status): ?>
          <li><?= htmlspecialchars(str_replace('_', '.', $emailKey)) ?> — <em><?= htmlspecialchars($status) ?></em></li>
        <?php endforeach; ?>
      <?php else: ?>
        <p>No pending invites.</p>
      <?php endif; ?>
    </ul>
  </div>
</div>

        
          <div id="Tasks" class="tabcontent">   
          <div class="tab-header">
        <h3>Tasks</h3>
        <?php if ($isOwner): ?>
          <button class="open-popup-btn" onclick="openPopup('taskPopup')">+ Add Task</button>
        <?php endif; ?>
      </div>


  <div class="card-tasks">
    <?php if (!empty($plan['tasks'])): ?>
      <?php foreach ($plan['tasks'] as $taskId => $task): ?>
        <div class="task-card">
          <form method="POST" style="display:flex; align-items: center;">
            <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
            <input type="hidden" name="owner_uid" value="<?= $uid ?>">
            <input type="hidden" name="task_id" value="<?= $taskId ?>">
            <input type="hidden" name="toggle_task" value="1">
            <input type="checkbox" onchange="this.form.submit()"
              <?= !empty($task['completed']) ? 'checked' : '' ?>>
            <span class="task-name"><?= htmlspecialchars($task['name']) ?></span>

            <!-- Display due date and time -->
            <?php if (!empty($task['due_date']) && !empty($task['due_time'])): ?>
              <span class="task-due" style="margin-left: 10px; font-size: 0.9em; color: gray;">
                (Due: <?= htmlspecialchars($task['due_date']) ?> at <?= htmlspecialchars($task['due_time']) ?>)
              </span>
            <?php endif; ?>
          </form>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p>No tasks available.</p>
    <?php endif; ?>
  </div>
</div>



  </div>
  <script>
document.addEventListener('DOMContentLoaded', () => {
  const tasks = <?= json_encode($plan['tasks'] ?? []) ?>;
  const calendar = document.getElementById('smallCalendar');
  const calendarMonthDisplay = document.getElementById('calendarMonth');
  const prevMonthBtn = document.getElementById('prevMonth');
  const nextMonthBtn = document.getElementById('nextMonth');
  
  let currentDate = new Date();

  const updateCalendar = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    const taskDates = Object.values(tasks)
      .map(task => task.due_date)
      .filter(Boolean);

    calendar.innerHTML = ''; // Clear current calendar

    // Update the month display
    calendarMonthDisplay.textContent = `${currentDate.toLocaleString('default', { month: 'long' })} ${year}`;

    const table = document.createElement('table');
    table.style.width = '100%';

    const header = document.createElement('tr');
    ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].forEach(day => {
      const th = document.createElement('th');
      th.textContent = day;
      header.appendChild(th);
    });
    table.appendChild(header);

    let date = 1;
    for (let i = 0; i < 6; i++) {
      const row = document.createElement('tr');

      for (let j = 0; j < 7; j++) {
        const cell = document.createElement('td');

        if (i === 0 && j < firstDay) {
          cell.textContent = '';
        } else if (date > daysInMonth) {
          break;
        } else {
          const fullDate = `${year}-${String(month + 1).padStart(2, '0')}-${String(date).padStart(2, '0')}`;
          cell.textContent = date;
          cell.className = 'calendar-day';
          if (taskDates.includes(fullDate)) {
            cell.classList.add('task-date');
          }
          date++;
        }
        row.appendChild(cell);
      }

      table.appendChild(row);
    }

    calendar.appendChild(table);
  };

  prevMonthBtn.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    updateCalendar();
  });

  nextMonthBtn.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    updateCalendar();
  });

  updateCalendar(); // Initial call to display the calendar
});

</script>
<!-- Announcement Popup -->
<div class="popup" id="announcementPopup">
  <div class="popup-content">
    <span class="close-popup" onclick="closePopup('announcementPopup')">&times;</span>
    <form method="POST">
      <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
      <textarea name="announcement_text" placeholder="Write your announcement..." required></textarea>
      <button type="submit" name="add_announcement">Post Announcement</button>
    </form>
  </div>
</div>

<!-- Notes Popup -->
<div class="popup" id="notesPopup">
  <div class="popup-content">
    <span class="close-popup" onclick="closePopup('notesPopup')">&times;</span>
    <form method="POST">
      <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
      <textarea name="note_text" placeholder="Write your note..." required></textarea>
      <button type="submit" name="add_note">Add Note</button>
    </form>
  </div>
</div>

<div class="popup" id="taskPopup">
  <div class="popup-content">
    <span class="close-popup" onclick="closePopup('taskPopup')">&times;</span>
    <h4>Add New Task</h4>
    <form method="POST">
      <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
      <div class="form-group">
        <label for="task_name">Task Name</label>
        <input type="text" id="task_name" name="task_name" required>
      </div>
      <div class="form-group-inline">
        <div>
          <label for="due_date">Due Date</label>
          <input type="date" id="due_date" name="due_date" required>
        </div>
        <div>
          <label for="due_time">Due Time</label>
          <input type="time" id="due_time" name="due_time" required>
        </div>
      </div>
      <button type="submit" name="add_task">Add Task</button>
    </form>
  </div>
</div>
<!-- Invite Popup Modal -->
<div class="popup" id="invitePopup">
  <div class="popup-content">
    <span class="close-popup" onclick="closePopup('invitePopup')">&times;</span>
    <h4>Invite Collaborator</h4>
    <form method="POST">
      <input type="hidden" name="plan_id" value="<?= htmlspecialchars($planId) ?>">
      <div class="form-group">
        <label for="invite_email">Email</label>
        <input type="email" id="invite_email" name="invite_email" placeholder="user@example.com" required>
      </div>
      <div class="form-group">
        <label for="invite_role">Role</label>
        <select id="invite_role" name="invite_role">
          <option value="collaborator" selected>Collaborator</option>
          <option value="assistant admin">Assistant Admin</option>
        </select>
      </div>
      <button type="submit" name="invite_user">Send Invite</button>
    </form>
  </div>
</div>

<script>
function openPopup(id) {
  document.getElementById(id).style.display = 'block';
}
function closePopup(id) {
  document.getElementById(id).style.display = 'none';
}
</script>
<script>
function toggleInfoDropdown() {
  const dropdown = document.getElementById('infoDropdown');
  dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
}

document.addEventListener('click', function(event) {
  const button = document.querySelector('.info-btn');
  const dropdown = document.getElementById('infoDropdown');
  if (!button.contains(event.target) && !dropdown.contains(event.target)) {
    dropdown.style.display = 'none';
  }
});
</script>

</body>
</html>
