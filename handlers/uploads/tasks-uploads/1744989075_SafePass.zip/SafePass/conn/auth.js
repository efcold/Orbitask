document.addEventListener("DOMContentLoaded", function () {
    const auth = firebase.auth();
    const provider = new firebase.auth.GoogleAuthProvider();
    provider.addScope('profile');
    document.getElementById("googleLoginBtn").addEventListener("click", function () {
      auth.signInWithPopup(provider)
        .then(result => {
          const user = result.user;
          // Store user data in session storage
          let photoURL = user.photoURL || (user.providerData.length > 0 ? user.providerData[0].photoURL : "");

          console.log("User Photo URL:", photoURL); // Debugging line


          const userData = {
            uid: user.uid,
            email: user.email,
            displayName: user.displayName,
            photoURL: photoURL 
          };
          sessionStorage.setItem("userData", JSON.stringify(userData));
  
          // Check if user exists via check_user.php
          fetch(`../auth/check_user.php?uid=${encodeURIComponent(user.uid)}`)
            .then(response => response.json())
            .then(data => {
              if (data.exists) {
                // User exists: redirect directly to dashboard
                window.location.href = "../directives/dashboard.php";
              } else {
                // New user: redirect to confirmation page with UID in URL
                window.location.href = "../auth/user_confirmation.php?uid=" + encodeURIComponent(user.uid);
              }
            })
            .catch(error => console.error("Error checking user:", error));
        })
        .catch(error => console.error("Error during Google sign-in:", error));
    });
  });
  